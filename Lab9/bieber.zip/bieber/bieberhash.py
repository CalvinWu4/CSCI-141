"""
Calvin Wu
"""

from rit_lib import *
from hashtable import *
'''
def create_bills(filename,capacity):
    """
    Runs the simulation, finds out where everyone is ultimately seated, and report the final tab for each person.
    :param filename: text file
    :param capacity: int
    :return: NoneType
    """
    createHashTable(capacity)
    file=open(filename)
    message=''
    nameList=[]
    moneyList=[]
    c=0
    x=0
    y=0
    z=0
    lines=file.readlines()
    for i in lines:
        i=i.split()
    for i in lines:
        message+=i
        c+=2
    message=message.split()
    while c>0:
        if message[x] not in nameList:
            nameList.append(message[x])
            moneyList.append(int(message[x+1][1]))
        else:
            while nameList[y] != message[x]:
                y+=1
            moneyList[y]+=int(message[x+1][1])
        x+=2
        c-=2
    while z!=len(nameList)-1:
        print(nameList[z]+' owes '+str(moneyList[z])+' and is in seat '+str(hashFn1(nameList[z],capacity)))
        z+=1
'''
def create_bills(filename,capacity):
    """
    Runs the simulation, finds out where everyone is ultimately seated, and report the final tab for each person.
    :param filename: text file
    :param capacity: int
    :return: NoneType
    """
    x=createHashTable(capacity)
    file=open(filename)
    message=''
    nameList=[]
    moneyList=[]
    c=0
    x=0
    y=0
    z=0
    lines=file.readlines()
    for i in lines:
        i=i.split()
    for i in lines:
        message+=i
        c+=2
    message=message.split()
    while c>0:
        put(x,message[x],message[x+1][1])
        x+=2
        c-=2
        '''
    while z!=len(nameList)-1:
        print(nameList[z]+' owes '+str(moneyList[z])+' and is in seat '+str(hashFn1(nameList[z],capacity)))
        z+=1
        '''
def main():
    """
    Prompts the user for the for the size of the hash table to create and for the filename to read and calls the
    create_bills function to run the simulation
    :return: string (final tab for each person)
    """
    create_bills(input('Name of input file: '),int(input('How big a hashtable to use: ')))
main()

x=createHashTable(capacity=100)
put(x,'ZACHARRY',5)
print(has(x,'ZACHARRY'))
#print(get(x,'ZACHARRY'))
print(indexOf(x,'ZACHARRY'))
