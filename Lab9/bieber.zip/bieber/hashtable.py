"""
description: open addressing Hash Table for CS 141 Lecture
file: hashtable.py
language: python3
author: sps@cs.rit.edu Sean Strout
author: jeh@cs.rit.edu James Heliotis
author: anh@cs.rit.edu Arthur Nunes-Harwitt
author: jsb@cs.rit.edu Jeremy Brown
author: as@cs.rit.edu Amar Saric
author: cxw7054@rit.edu Calvin Wu
"""

from rit_lib import *

def hashFn1(str,capacity):
    """
    Identifies the person's primary seat by multiplying the ordinal value of each letter of his/her name
    :param str: string (person's name)
    :return: int (primary seat number)
    """
    value1=1
    i=0
    for i in str:
        i=i.upper()
        value1=(value1*ord(i))-64
    return value1%capacity

def hashFn2(str,capacity):
    """
    Identifies the person's primary seat by multiplying the ordinal value of each letter of his/her name
    :param str: string (person's name)
    :return: int (primary seat number)
    """
    value2=1
    i=0
    for i in str:
        i=i.upper()
        value2+=ord(i)-64
    return value2%capacity
'''
def hashFn12(str):
    """
    Identifies the person's primary seat by multiplying the ordinal value of each letter of his/her name
    :param str: string (person's name)
    :return: int (primary seat number)
    """
    value1=1
    i=0
    name=''
    while str[i] != ' ':
        name+=str[i]
        i+=1
    for i in name:
        i=i.upper()
        value1=(value1*ord(i))-64
    return value1%100
'''
class HashTable(struct):
    """
           The HashTable data structure contains a collection of values
       where each value is located by a hashable key.
       No two values may have the same key, but more than one
       key may have the same value.
       table is the list holding the hash table
       size is the number of elements in occupying the hashtable

    """
    _slots = ((list, 'table'), (int, 'size'))


def createHashTable(capacity):
    """
    createHashTable: NatNum? -> HashTable
    """
    if capacity < 2:
        capacity = 2
    aHashTable = HashTable([None for _ in range(capacity)], 0)
    return aHashTable


def HashTableToStr(hashtable):
    """
    HashTableToStr: HashTable -> String
    """
    result = ""
    for i in range(len(hashtable.table)):
        e = hashtable.table[i]
        if not e == None:
            result += str(i) + ": "
            result += EntryToStr(e) + "\n"
    return result


class Entry(struct):
    """
       A class used to hold key/value pairs. Modified to include bumped?.
    """

    _slots = ((object, "key"), (object, "value"))


def EntryToStr(entry):
    """
    EntryToStr: Entry -> String
    return the string representation of the entry.
    """
    return "(" + str(entry.key) + ", " + str(entry.value) + ")"


def hash_function(val, n):
    """
    hash_function: K NatNum -> NatNum
    Compute a hash of the val string that is in [0 ... n).
    """
    hashcode = hash(val) % n
    # hashcode = 0
    # hashcode = len(val) % n
    return hashcode

def keys(hTable):
    """
    keys: HashTable(K, V) -> List(K)
    Return a list of keys in the given hashTable.
    """
    result = []
    for entry in hTable.table:
        if entry != None:
            result.append(entry.key)
    return result

def has(hTable, key):
    """
    Returns True if a given key is in the table based on the two possible locations where it could reside.
    :param hTable: HashTable
    :param key: String (Name)
    :return: Boolean
    """
    key=key.upper()
    if has1(hTable, key) == True or has2(hTable, key) == True:
        return True
    else:
        return False

def has1(hTable, key):
    """
    Returns True if a given key is in the table based on the the primary location.
    :param hTable: HashTable
    :param key: String (Name)
    :return: Boolean
    """
    index = hashFn1(key,capacity=100)
    startIndex = index  # We must make sure we don't go in circles.
    while hTable.table[ index ] != None and hTable.table[ index ].key != key:
        index = (index + 1) % len(hTable.table)
        if index == startIndex:
            return False
    return hTable.table[ index ] != None

def has2(hTable, key):
    """
    Returns True if a given key is in the table based on the secondary location.
    :param hTable: HashTable
    :param key: String (Name)
    :return: Boolean
    """
    index = hashFn2(key,capacity=100)
    startIndex = index  # We must make sure we don't go in circles.
    while hTable.table[ index ] != None and hTable.table[ index ].key != key:
        index = (index + 1) % len(hTable.table)
        if index == startIndex:
            return False
    return hTable.table[ index ] != None

def get(hTable, key):
    """
    Return the value associated with the given key in
    the given hash table.
    Precondition: has(hTable, key)
    :param hTable: hTable
    :param key: string
    :return: value
    """
    key=key.upper()
    if has(hTable.table,key):
        return hTable.table[indexOf(hTable.table,key)].value
    else:
        raise IndexError

def indexOf(hTable, key):
    """
    Return the value associated with the given key in
    the given hash table.
    Precondition: has(hTable, key)
    :param hTable: hTable
    :param key: string
    :return int
    """
    key=key.upper()
    index = hashFn1(key,capacity=100)
    startIndex = index  # We must make sure we don't go in circles.
    while hTable.table[ index ] != None and hTable.table[ index ].key != key:
        index = (index + 1) % len(hTable.table)
        if index == startIndex:
            raise Exception("Hash table does not contain key.")
    if hTable.table[ index ] == None:
        raise Exception("Hash table does not contain key:", key)
    else:
        return hTable.table[ index ].value

def put(hTable, key, value):
    """
    Correctly places a new key and associated value in the table or
    updates a key's value based on hash function 1.
    :param hTable: hTable
    :param key: string
    :param value: int
    :return: NoneType
    """
    key=key.upper()
    if has(hTable,key):
        hTable.table[indexOf(hTable,key)].value+=value
    else:
        index=hashFn1(key,len(hTable.table))
        if hTable.table[index]==None:
            hTable.table[index]=Entry(key,value)
        else:
            if hashFn1((hTable.table[index].key,len(hTable.table))==index):
                put2(hTable,hTable.table[index].key,hTable.table[index].value)
                hTable.table[index]=Entry(key,value)
            else:
                raise Exception('Could not seat everyone')

def put2(hTable, key, value):
    """
    Correctly places a new key and associated value in the table or
    updates a key's value based on hash function 2.
    :param hTable: hTable
    :param key: string
    :param value: int
    :return: NoneType
    """
    key=key.upper()
    index=hashFn2(key,len(hTable.table))
    if hTable[index]==None:
        hTable.table[index]=Entry(key,value)
    else:
        if hashFn1((hTable.table[index].key,len(hTable.table))==index):
            put2(hTable,hTable.table[index].key,hTable.table[index].value)
            hTable.table[index]=Entry(key,value)
        else:
            raise Exception('Could not seat everyone')
